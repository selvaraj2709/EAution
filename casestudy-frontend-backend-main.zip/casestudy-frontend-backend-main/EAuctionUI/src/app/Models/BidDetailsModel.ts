export class BidDetailsModel{
  firstName: string = ""
  phone:string = ""
  bidAmount: number = 0
  email: string = ""
}
