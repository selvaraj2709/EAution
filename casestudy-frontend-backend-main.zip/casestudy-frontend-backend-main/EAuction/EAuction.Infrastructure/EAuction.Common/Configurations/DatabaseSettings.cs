namespace EAuction.Infrastructure.Common
{
    public class DatabaseSettings
    {
        public string ConnectionString { get; set; }
        public string Store { get; set; }
    }
}