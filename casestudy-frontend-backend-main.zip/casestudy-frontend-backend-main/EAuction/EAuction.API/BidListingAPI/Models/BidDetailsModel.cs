﻿namespace EAuction.BidListing.API.Models
{
    public class BidDetailsModel
    {
        public string FirstName { get; set; }
        public string Phone { get; set; }
        public decimal BidAmount { get; set; }
        public string Email { get; set; }
    }
}