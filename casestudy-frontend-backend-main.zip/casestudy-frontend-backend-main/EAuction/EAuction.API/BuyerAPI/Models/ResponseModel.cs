﻿namespace EAuction.Buyer.API.Models
{
    public class ResponseModel
    {
        public string Message { get; set; }
    }
}