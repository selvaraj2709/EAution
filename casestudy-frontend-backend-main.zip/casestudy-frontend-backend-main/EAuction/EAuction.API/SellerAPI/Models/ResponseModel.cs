﻿namespace EAuction.Seller.API.Models
{
    public class ResponseModel
    {
        public string Message { get; set; }
    }
}